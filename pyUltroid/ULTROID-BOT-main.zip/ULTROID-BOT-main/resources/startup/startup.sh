#!/bin/bash
# Ultroid - UserBot
# Copyright (C) 2020 ULTROID-OP
#
# This file is a part of < https://github.com/ULTROID-OP/ULTROID-BOT/ >
# PLease read the GNU Affero General Public License in <https://www.github.com/ULTROID-OP/Ultroid/blob/main/LICENSE/>.
 
echo "
 
        +-+ +-+ +-+ +-+ +-+ +-+ +-+
        |U| |L| |T| |R| |O| |I| |D|
        +-+ +-+ +-+ +-+ +-+ +-+ +-+
 
 
      Visit @ULTROID_OP for updates!!

"
 
python3 -m pyUltroid
