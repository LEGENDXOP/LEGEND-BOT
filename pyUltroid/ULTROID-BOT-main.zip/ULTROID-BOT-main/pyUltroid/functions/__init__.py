from pyUltroid import *
from ..dB.database import Var

DANGER = [
    "APP_ID",
    "API_HASH",
    "SESSION",
    "BOT_TOKEN",
    "HEROKU_API",
    "base64",
    "base32",
    "get_me",
    ".me",
    "NewMessage",
    "addons/",
    "cryptography",
    "stderr",
    "stdout",
    "PIPE",
    "REDIS_PASSWORD",
    "herokuapp.com",
    "phone",
    "load_addons",
    "load_plugins",
]
